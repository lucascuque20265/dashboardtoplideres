 import React, { createContext, useContext, useState, useCallback } from 'react';
 import { Candidate, ProductService, Demand, Program, Status, DashboardFilters } from '@/types';
 import { mockCandidates } from '@/data/mockData';
 
 interface DataContextType {
   candidates: Candidate[];
   filters: DashboardFilters;
   isAdmin: boolean;
   setIsAdmin: (value: boolean) => void;
   setFilters: (filters: DashboardFilters) => void;
   addCandidate: (candidate: Omit<Candidate, 'id' | 'productsServices'>) => void;
   updateCandidate: (id: string, data: Partial<Candidate>) => void;
   deleteCandidate: (id: string) => void;
   addProductService: (candidateId: string, product: Omit<ProductService, 'id' | 'demands'>) => void;
   updateProductService: (candidateId: string, productId: string, data: Partial<ProductService>) => void;
   deleteProductService: (candidateId: string, productId: string) => void;
   addDemand: (candidateId: string, productId: string, demand: Omit<Demand, 'id'>) => void;
   updateDemand: (candidateId: string, productId: string, demandId: string, data: Partial<Demand>) => void;
   deleteDemand: (candidateId: string, productId: string, demandId: string) => void;
 }
 
 const DataContext = createContext<DataContextType | undefined>(undefined);
 
 export function DataProvider({ children }: { children: React.ReactNode }) {
   const [candidates, setCandidates] = useState<Candidate[]>(mockCandidates);
   const [isAdmin, setIsAdminState] = useState(() => {
     const saved = localStorage.getItem('isAdmin');
     return saved === 'true';
   });
   const [filters, setFilters] = useState<DashboardFilters>({
     programs: [],
     status: [],
     dateRange: { start: null, end: null },
     search: '',
     cities: [],
     states: [],
   });

   const setIsAdmin = (value: boolean) => {
     setIsAdminState(value);
     if (value) {
       localStorage.setItem('isAdmin', 'true');
     } else {
       localStorage.removeItem('isAdmin');
     }
   };
 
   const generateId = () => Math.random().toString(36).substring(2, 9);
 
   const addCandidate = useCallback((candidate: Omit<Candidate, 'id' | 'productsServices'>) => {
     setCandidates(prev => [...prev, { ...candidate, id: generateId(), productsServices: [] }]);
   }, []);
 
   const updateCandidate = useCallback((id: string, data: Partial<Candidate>) => {
     setCandidates(prev => prev.map(c => c.id === id ? { ...c, ...data } : c));
   }, []);
 
   const deleteCandidate = useCallback((id: string) => {
     setCandidates(prev => prev.filter(c => c.id !== id));
   }, []);
 
   const addProductService = useCallback((candidateId: string, product: Omit<ProductService, 'id' | 'demands'>) => {
     setCandidates(prev => prev.map(c => {
       if (c.id === candidateId) {
         return {
           ...c,
           productsServices: [...c.productsServices, { ...product, id: generateId(), demands: [] }]
         };
       }
       return c;
     }));
   }, []);
 
   const updateProductService = useCallback((candidateId: string, productId: string, data: Partial<ProductService>) => {
     setCandidates(prev => prev.map(c => {
       if (c.id === candidateId) {
         return {
           ...c,
           productsServices: c.productsServices.map(p => p.id === productId ? { ...p, ...data } : p)
         };
       }
       return c;
     }));
   }, []);
 
   const deleteProductService = useCallback((candidateId: string, productId: string) => {
     setCandidates(prev => prev.map(c => {
       if (c.id === candidateId) {
         return {
           ...c,
           productsServices: c.productsServices.filter(p => p.id !== productId)
         };
       }
       return c;
     }));
   }, []);
 
   const addDemand = useCallback((candidateId: string, productId: string, demand: Omit<Demand, 'id'>) => {
     setCandidates(prev => prev.map(c => {
       if (c.id === candidateId) {
         return {
           ...c,
           productsServices: c.productsServices.map(p => {
             if (p.id === productId) {
               return { ...p, demands: [...p.demands, { ...demand, id: generateId() }] };
             }
             return p;
           })
         };
       }
       return c;
     }));
   }, []);
 
   const updateDemand = useCallback((candidateId: string, productId: string, demandId: string, data: Partial<Demand>) => {
     setCandidates(prev => prev.map(c => {
       if (c.id === candidateId) {
         return {
           ...c,
           productsServices: c.productsServices.map(p => {
             if (p.id === productId) {
               return {
                 ...p,
                 demands: p.demands.map(d => d.id === demandId ? { ...d, ...data } : d)
               };
             }
             return p;
           })
         };
       }
       return c;
     }));
   }, []);
 
   const deleteDemand = useCallback((candidateId: string, productId: string, demandId: string) => {
     setCandidates(prev => prev.map(c => {
       if (c.id === candidateId) {
         return {
           ...c,
           productsServices: c.productsServices.map(p => {
             if (p.id === productId) {
               return { ...p, demands: p.demands.filter(d => d.id !== demandId) };
             }
             return p;
           })
         };
       }
       return c;
     }));
   }, []);
 
   return (
     <DataContext.Provider value={{
       candidates,
       filters,
       isAdmin,
       setIsAdmin,
       setFilters,
       addCandidate,
       updateCandidate,
       deleteCandidate,
       addProductService,
       updateProductService,
       deleteProductService,
       addDemand,
       updateDemand,
       deleteDemand,
     }}>
       {children}
     </DataContext.Provider>
   );
 }
 
 export function useData() {
   const context = useContext(DataContext);
   if (context === undefined) {
     throw new Error('useData must be used within a DataProvider');
   }
   return context;
 }